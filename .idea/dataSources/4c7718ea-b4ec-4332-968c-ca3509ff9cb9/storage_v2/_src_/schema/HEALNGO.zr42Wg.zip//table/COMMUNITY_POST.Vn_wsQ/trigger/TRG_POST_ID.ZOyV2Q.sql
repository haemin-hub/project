create trigger TRG_POST_ID
    before insert
    on COMMUNITY_POST
    for each row
BEGIN
    SELECT post_seq.NEXTVAL INTO :NEW.post_id FROM dual;
END;
/

